<div class="container-fluid bg-dark text-light">
    
    <p class="text-center mb-0">copyright forum i discuss 2023 | allright is reserved</p>
</div>