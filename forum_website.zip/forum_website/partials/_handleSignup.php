<?php 
$showError = "false";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include '_dbconnect.php';
    $user_email = $_POST['signupEmail'];
    $pass = $_POST['signupPassword'];
    $cpass = $_POST['signupcPassword'];
    
    //check whether this email exists 
    $existSql = "SELECT * FROM `users` WHERE  user_email='$user_email' "; 
    $result = mysqli_query($conn,$existSql);
    $numRows = mysqli_num_rows($result);
    if($numRows>0){
        $showError = "email already in use";
    }
    else{
        if($pass == $cpass){
            $hass = password_hash($pass, PASSWORD_DEFAULT);
            $sql="INSERT INTO `users` (`user_email`, `user_pass`, `timestamp`) VALUES ('$user_email', '$hass', current_timestamp())";
            $result = mysqli_query($conn, $sql);
            if($result){
                $showAlert = true;
                header("Location: /forum_website/index.php?signupsuccess=true");
                exit();
            }
        }
        else{
            $showError = "password do not mach";
            //header("Location: /forum_website/index.php?signupsuccess=false&error=$showError");
        }
    }
    header("Location: /forum_website/index.php?signupsuccess=false&error=$showError");

}

?>