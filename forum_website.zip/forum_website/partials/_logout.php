<?php
session_start();
echo "loging you out plrase wait..";

session_destroy();
header("Location: /forum_website");
?>